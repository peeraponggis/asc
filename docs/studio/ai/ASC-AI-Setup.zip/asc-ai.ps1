﻿<#
  asc-ai.ps1 — ชุดติดตั้งผู้ช่วย AI ของ ASC Studio แบบพกพา (แผน docs/ai-knowledge-plan.md · K2a)
    install    ติดตั้ง (ตรวจเครื่อง → เลือกโฟลเดอร์ → แลกรหัสติดตั้ง → Ollama พกพา → โมเดล → ทดสอบ → ทางลัด)
    start      เปิดผู้ช่วย AI (Ollama ของชุดนี้ · พอร์ตแยก · รับเฉพาะในเครื่อง)
    stop       ปิดผู้ช่วย AI
    status     ดูสถานะ
    uninstall  ถอนการติดตั้ง (คืนสิทธิ์เครื่องในบัญชี แล้วลบโฟลเดอร์ ทางลัด และลิงก์ ascs-ai://)
  ทุกอย่างอยู่ในโฟลเดอร์เดียว ไม่ต้องใช้สิทธิ์ admin · ค่า OLLAMA_* ตั้งเฉพาะโปรเซสนี้ ไม่แก้ค่าทั้งเครื่อง
  ไม่ถามอีเมล/รหัสผ่าน · ส่งออกนอกเครื่องเฉพาะ: รหัสติดตั้ง + แฮชเครื่อง + ชื่อเครื่อง (Supabase) และดาวน์โหลดจาก GitHub/Ollama
  -TestMode = สำหรับผู้พัฒนา: ข้ามการแลกรหัส (ไม่ต่อ Supabase)
#>
param(
  [ValidateSet('install', 'start', 'stop', 'status', 'uninstall')][string]$Action = 'install',
  [string]$Folder = '',
  [string]$Code = '',
  [string]$ModelsDir = '',
  [switch]$TestMode,
  [switch]$Yes
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Cfg = Get-Content -Raw -Encoding UTF8 (Join-Path $Here 'ai-local.json') | ConvertFrom-Json
$Port = [int]$Cfg.port
$Base = "http://127.0.0.1:$Port"
$script:LogFile = $null

function Say([string]$msg, [string]$color = 'Gray') {
  Write-Host $msg -ForegroundColor $color
  if ($script:LogFile) { Add-Content -Path $script:LogFile -Value ("{0:yyyy-MM-dd HH:mm:ss}  {1}" -f (Get-Date), $msg) -Encoding UTF8 }
}
function Step([int]$n, [string]$msg) { Say ''; Say ("[{0}/9] {1}" -f $n, $msg) 'Cyan' }
function Fail([string]$msg) { Say ''; Say ("✖ " + $msg) 'Red'; exit 1 }
function Ask([string]$q, [bool]$def) {
  if ($Yes) { return $def }
  $hint = if ($def) { '[Y/n]' } else { '[y/N]' }
  $a = Read-Host "$q $hint"
  if ([string]::IsNullOrWhiteSpace($a)) { return $def }
  return $a.Trim().ToLower().StartsWith('y')
}

function StatePath([string]$dir) { Join-Path $dir 'state.json' }
function LoadState([string]$dir) {
  $p = StatePath $dir
  if (Test-Path $p) { return Get-Content -Raw -Encoding UTF8 $p | ConvertFrom-Json }
  return $null
}
function SaveState([string]$dir, $st) { $st | ConvertTo-Json | Set-Content -Path (StatePath $dir) -Encoding UTF8 }

function ApiUp { try { $null = Invoke-RestMethod "$Base/api/version" -TimeoutSec 2; return $true } catch { return $false } }

# ตั้งค่าเฉพาะโปรเซสนี้ (โปรเซสลูก ollama serve ได้ค่าเหล่านี้) — ไม่แตะค่าของทั้งเครื่อง
function SetEnv($st) {
  $env:OLLAMA_HOST = "127.0.0.1:$Port"
  $env:OLLAMA_MODELS = $st.modelsDir
  $env:OLLAMA_ORIGINS = ($Cfg.origins -join ',')
  $env:OLLAMA_KEEP_ALIVE = '5m'
  $env:OLLAMA_MAX_LOADED_MODELS = '1'
  $env:OLLAMA_NUM_PARALLEL = '1'
}

function StartServer($st) {
  if (ApiUp) { return $true }
  SetEnv $st
  Start-Process -FilePath $st.ollamaExe -ArgumentList 'serve' -WindowStyle Hidden | Out-Null
  for ($i = 0; $i -lt 40; $i++) { Start-Sleep -Milliseconds 500; if (ApiUp) { return $true } }
  return $false
}

function StopServer {
  $c = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($c) { & taskkill.exe /PID $c.OwningProcess /T /F | Out-Null; return $true }
  return $false
}

function FindDir {
  if ($Folder) { return $Folder }
  $def = Join-Path $env:LOCALAPPDATA $Cfg.folderName
  if (Test-Path (StatePath $def)) { return $def }
  if (Test-Path (StatePath $Here)) { return $Here }   # สคริปต์ที่ถูกคัดลอกไปไว้ในโฟลเดอร์ติดตั้ง
  return $def
}

function MachineHash {
  $g = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid).MachineGuid
  $sha = [Security.Cryptography.SHA256]::Create()
  $bytes = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes("asc-studio-ai:" + $g))
  return (($bytes | ForEach-Object { $_.ToString('x2') }) -join '')
}

function SupabaseCfg {
  $js = (Invoke-WebRequest $Cfg.supabaseConfigUrl -UseBasicParsing -TimeoutSec 20).Content
  $u = [regex]::Match($js, "SUPABASE_URL\s*=\s*'([^']+)'").Groups[1].Value
  $k = [regex]::Match($js, "SUPABASE_ANON_KEY\s*=\s*'([^']+)'").Groups[1].Value
  if (-not $u -or -not $k) { Fail 'อ่านการตั้งค่า ASC Cloud ไม่ได้ — ตรวจอินเทอร์เน็ตแล้วลองใหม่' }
  return @{ url = $u.TrimEnd('/'); key = $k }
}

function Rpc($sb, [string]$fn, $body) {
  $json = $body | ConvertTo-Json -Compress
  return Invoke-RestMethod -Method Post -Uri "$($sb.url)/rest/v1/rpc/$fn" -TimeoutSec 30 `
    -Headers @{ apikey = $sb.key } -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($json))
}

function ExistingOllama {
  $cands = @()
  $cmd = Get-Command ollama.exe -ErrorAction SilentlyContinue
  if ($cmd) { $cands += $cmd.Source }
  $cands += (Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe')
  foreach ($c in $cands) { if ($c -and (Test-Path $c)) { return $c } }
  return $null
}

# ---- โมเดลที่มีอยู่แล้วในเครื่อง (โฟลเดอร์โมเดลของ Ollama เดิม) — ใช้ร่วมได้ ไม่ต้องดาวน์โหลดซ้ำ
function ManifestPath([string]$dir, [string]$model) {
  $name = $model; $tag = 'latest'
  if ($model -match '^(.*):([^/:]+)$') { $name = $Matches[1]; $tag = $Matches[2] }
  if ($name -notmatch '/') { $name = "library/$name" }
  return Join-Path $dir ('manifests\registry.ollama.ai\' + ($name -replace '/', '\') + '\' + $tag)
}
# มีครบทั้ง manifest และไฟล์ข้อมูลทุกชิ้น = ใช้ได้ (ดาวน์โหลดค้างครึ่งทาง = ไม่นับ) · คืนขนาด GB
function ModelInfo([string]$dir, [string]$model) {
  if (-not $dir) { return $null }
  $p = ManifestPath $dir $model
  if (-not (Test-Path $p)) { return $null }
  try { $m = Get-Content -Raw $p | ConvertFrom-Json } catch { return $null }
  $size = 0
  foreach ($l in $m.layers) {
    if (-not (Test-Path (Join-Path $dir ('blobs\' + ($l.digest -replace ':', '-'))))) { return $null }
    $size += $l.size
  }
  return [pscustomobject]@{ dir = $dir; gb = $size / 1GB }
}
function ListModels([string]$dir) {
  $root = Join-Path $dir 'manifests\registry.ollama.ai'
  if (-not (Test-Path $root)) { return @() }
  return @(Get-ChildItem $root -Recurse -File | ForEach-Object {
      $rel = $_.FullName.Substring($root.Length + 1) -split '\\'
      if ($rel.Count -ge 3) {
        $full = if ($rel[0] -eq 'library') { $rel[1] } else { $rel[0] + '/' + $rel[1] }
        if ($rel[2] -eq 'latest') { $full } else { $full + ':' + $rel[2] }
      }
    })
}
function CandidateModelDirs {
  $c = @([Environment]::GetEnvironmentVariable('OLLAMA_MODELS', 'User'), [Environment]::GetEnvironmentVariable('OLLAMA_MODELS', 'Machine'), (Join-Path $env:USERPROFILE '.ollama\models'))
  return @($c | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique)
}

function Shortcut([string]$path, [string]$target, [string]$arguments, [string]$desc) {
  $ws = New-Object -ComObject WScript.Shell
  $s = $ws.CreateShortcut($path)
  $s.TargetPath = $target; $s.Arguments = $arguments; $s.Description = $desc
  $s.WorkingDirectory = Split-Path -Parent $target
  $s.Save()
}

function Links([string]$dir) {
  $desk = [Environment]::GetFolderPath('Desktop')
  $menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'ASC Studio'
  $boot = [Environment]::GetFolderPath('Startup')
  return @{
    start = @((Join-Path $desk 'เปิดผู้ช่วย AI (ASC Studio).lnk'), (Join-Path $menu 'เปิดผู้ช่วย AI (ASC Studio).lnk'))
    remove = @((Join-Path $menu 'ถอนผู้ช่วย AI (ASC Studio).lnk'))
    menu = $menu
    boot = (Join-Path $boot 'ASC Studio AI.lnk')
  }
}

function Test-Model($st) {
  $sys = 'คุณคือผู้ช่วยของโปรแกรม ASC Studio ตอบเป็นภาษาไทยสั้น ๆ โดยใช้ข้อมูลใน "ความรู้" เท่านั้น ถ้าความรู้ไม่มีคำตอบ ให้ตอบว่า "ไม่พบในคู่มือ"'
  $know = 'เปิดงานเก่าให้เลือกไฟล์เดียวที่ชื่อลงท้าย _design-auto.json ไฟล์นี้มีผังหลังคา อุปกรณ์ สตริง และภาพแผนที่ครบ ไม่ต้องเลือกไฟล์อื่นในโฟลเดอร์'
  $body = @{ model = $Cfg.model; stream = $false; think = $false; options = @{ temperature = 0.2; num_predict = 160 }
    messages = @(@{ role = 'system'; content = $sys }, @{ role = 'user'; content = "ความรู้: $know`n`nคำถาม: จะเปิดงานที่ทำไว้ ต้องเลือกไฟล์ไหน" }) }
  $json = $body | ConvertTo-Json -Depth 5 -Compress
  $t0 = Get-Date
  $r = Invoke-RestMethod -Method Post -Uri "$Base/api/chat" -TimeoutSec 600 -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($json))
  $sec = ((Get-Date) - $t0).TotalSeconds
  $rate = if ($r.eval_duration -gt 0) { $r.eval_count / ($r.eval_duration / 1e9) } else { 0 }
  Say ("  คำตอบ: " + ($r.message.content -replace '\s+', ' ').Trim()) 'White'
  Say ("  ใช้เวลา {0:N1} วินาที (รวมโหลดโมเดล) · ตอบ {1:N1} token/วินาที" -f $sec, $rate)
  try { $null = Invoke-RestMethod -Method Post -Uri "$Base/api/generate" -Body (@{ model = $Cfg.model; keep_alive = 0 } | ConvertTo-Json) -ContentType 'application/json' } catch { }
}

# ------------------------------------------------------------------ install
function Install {
  Say '══════════════════════════════════════════════' 'Yellow'
  Say ' ติดตั้งผู้ช่วย AI สำหรับ ASC Studio (ทำงานในเครื่องนี้ ข้อมูลงานไม่ออกนอกเครื่อง)' 'Yellow'
  Say '══════════════════════════════════════════════' 'Yellow'

  Step 1 'ตรวจเครื่อง'
  if (-not [Environment]::Is64BitOperatingSystem) { Fail 'ต้องเป็น Windows 64 บิต' }
  $ram = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB
  Say ("  RAM {0:N1} GB" -f $ram)
  # เครื่อง 8 GB รายงานได้ราว 7.6–7.9 GB
  if ($ram -lt ($Cfg.minRamGb * 0.93)) { Fail ("RAM น้อยกว่า {0} GB — ผู้ช่วย AI ในเครื่องจะช้ามาก ใช้ช่อง ""ถามวิธีใช้"" แบบค้นหาใน ascs แทน" -f $Cfg.minRamGb) }

  Step 2 'เลือกโฟลเดอร์ติดตั้ง'
  $dir = $Folder
  if (-not $dir) {
    $def = Join-Path $env:LOCALAPPDATA $Cfg.folderName
    Say "  ค่าเริ่มต้น: $def"
    if (-not $Yes) { $a = Read-Host '  กด Enter เพื่อใช้ค่าเริ่มต้น หรือพิมพ์โฟลเดอร์อื่น'; if ($a.Trim()) { $dir = $a.Trim().Trim('"') } }
    if (-not $dir) { $dir = $def }
  }
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $dir = (Resolve-Path $dir).Path
  $script:LogFile = Join-Path $dir 'install-log.txt'
  Say "  โฟลเดอร์: $dir"
  $st = LoadState $dir
  if (-not $st) { $st = [pscustomobject]@{ version = 1; folder = $dir; port = $Port; model = $Cfg.model; ollamaExe = ''; ownOllama = $false; modelsDir = ''; ownModels = $true; machineHash = ''; secret = ''; installedAt = '' } }

  $exist = ExistingOllama
  $useExist = $false
  if ($exist -and -not $st.ownOllama) {
    Say "  พบ Ollama ในเครื่องแล้ว: $exist"
    $useExist = Ask '  ใช้ Ollama ตัวนี้ (ไม่ต้องดาวน์โหลด ~1.5 GB · ชุดนี้ยังใช้พอร์ตและการตั้งค่าแยกของตัวเอง)?' $true
  }
  # โมเดลที่มีอยู่แล้ว: ติดตั้งซ้ำ (โฟลเดอร์ของชุดนี้) หรือโฟลเดอร์โมเดลของ Ollama เดิม
  $haveModel = $false
  if ($ModelsDir) { $haveModel = [bool](ModelInfo $ModelsDir $Cfg.model) }
  elseif ($st.modelsDir -and (ModelInfo $st.modelsDir $Cfg.model)) { $haveModel = $true; Say ("  มีโมเดล {0} ในชุดนี้แล้ว" -f $Cfg.model) 'Green' }
  else {
    foreach ($md in CandidateModelDirs) {
      $others = @(ListModels $md | Where-Object { $_ -and $_ -ne $Cfg.model })
      $mi = ModelInfo $md $Cfg.model
      if ($mi) {
        Say ("  พบโมเดล {0} ในเครื่องแล้ว ({1:N1} GB) ที่ {2}" -f $Cfg.model, $mi.gb, $md) 'Green'
        if ($others.Count) { Say ('  โมเดลอื่นในโฟลเดอร์นี้: ' + ($others -join ', ')) }
        if (Ask '  ใช้โมเดลที่มีอยู่แล้ว (ไม่ต้องดาวน์โหลดซ้ำ ~2.5 GB · ถอนชุดนี้แล้วโมเดลยังอยู่)?' $true) { $ModelsDir = $md; $haveModel = $true }
        break
      }
      if ($others.Count) { Say ("  พบโมเดลอื่นในเครื่อง ({0}) แต่ยังไม่มี {1} — จะดาวน์โหลดเพิ่ม" -f ($others -join ', '), $Cfg.model) }
    }
  }
  $needOllama = -not $useExist -and -not ($st.ownOllama -and $st.ollamaExe -and (Test-Path $st.ollamaExe))
  $needGb = 0.5
  if (-not $haveModel) { $needGb += [double]$Cfg.modelSizeGb }
  if ($needOllama) { $needGb += [double]$Cfg.minFreeDiskGb - [double]$Cfg.modelSizeGb - 0.5 }
  $free = (Get-PSDrive -Name (Split-Path -Qualifier $dir).TrimEnd(':')).Free / 1GB
  Say ("  ดิสก์ว่าง {0:N1} GB (ต้องการ ~{1:N1} GB)" -f $free, $needGb)
  if ($free -lt $needGb) { Fail 'ดิสก์ว่างไม่พอ — เลือกโฟลเดอร์บนไดรฟ์อื่น' }

  Step 3 'ยืนยันสิทธิ์ด้วยรหัสติดตั้ง'
  if ($st.secret) { Say '  เครื่องนี้ยืนยันสิทธิ์แล้ว (ติดตั้งซ้ำ/ต่อจากเดิม)' 'Green' }
  elseif ($TestMode) { Say '  โหมดทดสอบ: ข้ามการแลกรหัส' 'DarkYellow' }
  else {
    Say '  รหัสติดตั้งได้จาก ascs บน ASC Cloud: เมนู ผู้ช่วย AI › ติดตั้งในเครื่องนี้ › สร้างรหัสติดตั้ง'
    $sb = SupabaseCfg
    $mh = MachineHash
    $ok = $false
    for ($i = 1; $i -le 3 -and -not $ok; $i++) {
      $c = $Code
      if (-not $c -or $i -gt 1) { $c = Read-Host '  ใส่รหัสติดตั้ง (เช่น ASC-7K3P-9QXM)' }
      try { $r = Rpc $sb 'redeem_ai_install_code' @{ p_code = $c.Trim(); p_machine_hash = $mh; p_machine_name = $env:COMPUTERNAME } }
      catch { Fail ('ติดต่อ ASC Cloud ไม่ได้: ' + $_.Exception.Message) }
      if ($r.ok) {
        $ok = $true
        $st.machineHash = $mh; $st.secret = $r.secret
        SaveState $dir $st
        Say ("  ✔ ยืนยันแล้ว · บัญชีนี้ใช้ {0}/{1} เครื่อง" -f $r.machines, $r.max_machines) 'Green'
      } else { Say ('  ✖ ' + $r.error) 'Red' }
    }
    if (-not $ok) { Fail 'ยืนยันรหัสไม่สำเร็จ' }
  }

  Step 4 'Ollama (ตัวรันโมเดล AI)'
  if ($useExist) { $st.ollamaExe = $exist; $st.ownOllama = $false; Say "  ใช้ตัวเดิม: $exist" }
  elseif ($st.ownOllama -and (Test-Path $st.ollamaExe)) { Say "  มีอยู่แล้ว: $($st.ollamaExe)" }
  else {
    $zip = Join-Path $dir $Cfg.ollamaZip
    $url = "https://github.com/ollama/ollama/releases/download/$($Cfg.ollamaVersion)/$($Cfg.ollamaZip)"
    Say ("  ดาวน์โหลด Ollama {0} (~{1} MB) จาก GitHub — หลุดแล้วรันใหม่จะต่อจากเดิม" -f $Cfg.ollamaVersion, $Cfg.ollamaZipMb)
    & curl.exe -L --fail --retry 3 -C - -o $zip $url
    if ($LASTEXITCODE -ne 0) { Fail 'ดาวน์โหลด Ollama ไม่สำเร็จ — ตรวจอินเทอร์เน็ตแล้วรันใหม่' }
    Say '  ตรวจความถูกต้องของไฟล์ (SHA-256)…'
    $h = (Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
    if ($h -ne $Cfg.ollamaZipSha256) { Remove-Item $zip -Force; Fail 'ไฟล์ Ollama ไม่ตรงกับต้นฉบับ (ลบทิ้งแล้ว) — รันใหม่อีกครั้ง' }
    $od = Join-Path $dir 'ollama'
    New-Item -ItemType Directory -Force -Path $od | Out-Null
    Say '  แตกไฟล์…'
    & tar.exe -xf $zip -C $od
    if ($LASTEXITCODE -ne 0) { Expand-Archive -Path $zip -DestinationPath $od -Force }
    Remove-Item $zip -Force
    $st.ollamaExe = Join-Path $od 'ollama.exe'; $st.ownOllama = $true
    if (-not (Test-Path $st.ollamaExe)) { Fail 'ไม่พบ ollama.exe หลังแตกไฟล์' }
  }
  if ($ModelsDir) { $st.modelsDir = $ModelsDir; $st.ownModels = $false }
  elseif (-not $st.modelsDir) { $st.modelsDir = Join-Path $dir 'models'; $st.ownModels = $true }
  New-Item -ItemType Directory -Force -Path $st.modelsDir | Out-Null
  SaveState $dir $st

  Step 5 ("เปิดผู้ช่วย AI (พอร์ต {0} · รับเฉพาะในเครื่องนี้)" -f $Port)
  if (-not (StartServer $st)) { Fail "เปิด Ollama ไม่ขึ้นที่พอร์ต $Port — มีโปรแกรมอื่นใช้พอร์ตนี้อยู่หรือไม่" }
  Say '  ✔ ทำงานแล้ว' 'Green'

  Step 6 ("โมเดล {0}" -f $Cfg.model)
  if (ModelInfo $st.modelsDir $Cfg.model) { Say ("  มีอยู่แล้วที่ {0} — ไม่ต้องดาวน์โหลด" -f $st.modelsDir) 'Green' }
  else {
    Say ("  ดาวน์โหลด (~{0} GB) — หลุดแล้วรันใหม่จะต่อจากเดิม" -f $Cfg.modelSizeGb)
    SetEnv $st
    & $st.ollamaExe pull $Cfg.model
    if ($LASTEXITCODE -ne 0) { Fail 'ดาวน์โหลดโมเดลไม่สำเร็จ — รันตัวติดตั้งใหม่จะต่อจากเดิม' }
  }

  Step 7 'ทดสอบถามภาษาไทย'
  try { Test-Model $st } catch { Say ('  ⚠ ทดสอบไม่สำเร็จ: ' + $_.Exception.Message) 'DarkYellow' }

  Step 8 'คัดลอกตัวเปิด/ปิดไว้ในโฟลเดอร์ + ทางลัด'
  foreach ($f in 'asc-ai.ps1', 'ai-local.json', 'README-TH.txt') {
    $src = Join-Path $Here $f
    if ((Test-Path $src) -and ((Resolve-Path $src).Path -ne (Join-Path $dir $f))) { Copy-Item $src $dir -Force }
  }
  $ps = Join-Path $dir 'asc-ai.ps1'
  $bat = @{ 'Start-ASC-AI.bat' = 'start'; 'Stop-ASC-AI.bat' = 'stop'; 'Uninstall-ASC-AI.bat' = 'uninstall' }
  foreach ($k in $bat.Keys) {
    $pause = if ($bat[$k] -eq 'start') { 'timeout /t 5 >nul' } else { 'pause' }
    Set-Content -Path (Join-Path $dir $k) -Encoding ASCII -Value "@echo off`r`nchcp 65001 >nul`r`npowershell -NoProfile -ExecutionPolicy Bypass -File ""%~dp0asc-ai.ps1"" $($bat[$k])`r`n$pause"
  }
  $L = Links $dir
  New-Item -ItemType Directory -Force -Path $L.menu | Out-Null
  foreach ($p in $L.start) { Shortcut $p (Join-Path $dir 'Start-ASC-AI.bat') '' 'เปิดผู้ช่วย AI ของ ASC Studio' }
  foreach ($p in $L.remove) { Shortcut $p (Join-Path $dir 'Uninstall-ASC-AI.bat') '' 'ถอนผู้ช่วย AI ของ ASC Studio' }
  Say '  ✔ ทางลัด "เปิดผู้ช่วย AI (ASC Studio)" บนหน้าจอ + เมนูเริ่ม › ASC Studio' 'Green'
  if (Ask '  ให้ปุ่มใน ascs สั่งเปิดผู้ช่วย AI ได้ (ลิงก์ ascs-ai://)?' $true) {
    $key = "HKCU:\Software\Classes\$($Cfg.protocol)"
    New-Item -Path "$key\shell\open\command" -Force | Out-Null
    Set-ItemProperty -Path $key -Name '(default)' -Value 'URL:ASC Studio AI'
    Set-ItemProperty -Path $key -Name 'URL Protocol' -Value ''
    # ไม่ส่งค่าจากลิงก์ (%1) เข้าคำสั่ง — ลิงก์ทำได้แค่ "เปิด"
    Set-ItemProperty -Path "$key\shell\open\command" -Name '(default)' -Value ("powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File ""{0}"" start" -f $ps)
    Say '  ✔ ลิงก์ ascs-ai://start' 'Green'
  }
  if (Ask '  เปิดผู้ช่วย AI อัตโนมัติทุกครั้งที่เปิดเครื่อง (ตอนไม่ใช้ใช้ RAM น้อย)?' $false) {
    Shortcut $L.boot 'powershell.exe' ("-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File ""{0}"" start" -f $ps) 'ASC Studio AI'
    Say '  ✔ เปิดเองตอนเปิดเครื่อง' 'Green'
  }
  $st.installedAt = (Get-Date).ToString('s')
  SaveState $dir $st

  Step 9 'เสร็จ'
  Say '  ผู้ช่วย AI เปิดอยู่ · กลับไปที่ ascs กด "ตรวจอีกครั้ง" ในหน้าต่างผู้ช่วย AI' 'Green'
  Say '  ครั้งต่อไปเปิดด้วยทางลัด "เปิดผู้ช่วย AI (ASC Studio)" · ถอนออกที่เมนูเริ่ม › ASC Studio › ถอนผู้ช่วย AI'
  Say "  บันทึกการติดตั้ง: $script:LogFile"
}

# ------------------------------------------------------------------ uninstall
function Uninstall {
  $dir = FindDir
  $st = LoadState $dir
  if (-not $st) { Fail "ไม่พบการติดตั้งที่ $dir" }
  Say "ถอนผู้ช่วย AI ออกจาก $dir" 'Yellow'
  if (-not $Yes -and -not (Ask 'ยืนยันถอนการติดตั้ง?' $false)) { Say 'ยกเลิก'; return }
  if (StopServer) { Say '  ปิดผู้ช่วย AI แล้ว' }
  if ($st.secret -and $st.machineHash) {
    try { $ok = Rpc (SupabaseCfg) 'release_ai_install' @{ p_machine_hash = $st.machineHash; p_secret = $st.secret }; if ($ok) { Say '  คืนสิทธิ์เครื่องในบัญชีแล้ว' 'Green' } }
    catch { Say '  ⚠ คืนสิทธิ์เครื่องไม่สำเร็จ (ออฟไลน์?) — ยกเลิกเครื่องนี้เองได้ในหน้า ascs' 'DarkYellow' }
  }
  $L = Links $dir
  foreach ($p in @($L.start + $L.remove + $L.boot)) { if (Test-Path $p) { Remove-Item $p -Force } }
  if ((Test-Path $L.menu) -and -not (Get-ChildItem $L.menu)) { Remove-Item $L.menu -Force }
  $key = "HKCU:\Software\Classes\$($Cfg.protocol)"
  if (Test-Path $key) { Remove-Item $key -Recurse -Force }
  if ($st.ownOllama) { Remove-Item (Join-Path $dir 'ollama') -Recurse -Force -ErrorAction SilentlyContinue }
  # โฟลเดอร์โมเดลที่ใช้ร่วมกับของเดิม (-ModelsDir) ไม่ลบ
  if ($st.ownModels) { Remove-Item $st.modelsDir -Recurse -Force -ErrorAction SilentlyContinue }
  foreach ($f in 'state.json', 'Start-ASC-AI.bat', 'Stop-ASC-AI.bat', 'ai-local.json', 'README-TH.txt', 'install-log.txt') { Remove-Item (Join-Path $dir $f) -Force -ErrorAction SilentlyContinue }
  Say '  ✔ ถอนแล้ว — ลบโฟลเดอร์ที่เหลือ (ตัวถอน) ได้เอง' 'Green'
  Say "    $dir"
}

switch ($Action) {
  'install' { Install }
  'start' {
    $dir = FindDir; $st = LoadState $dir
    if (-not $st) { Fail "ยังไม่ได้ติดตั้ง (ไม่พบ $dir\state.json)" }
    if (StartServer $st) { Say "✔ ผู้ช่วย AI ทำงานแล้ว ($Base) — กลับไปที่ ascs ได้เลย" 'Green' } else { Fail "เปิดไม่ขึ้นที่พอร์ต $Port" }
  }
  'stop' { if (StopServer) { Say '✔ ปิดผู้ช่วย AI แล้ว' 'Green' } else { Say 'ผู้ช่วย AI ไม่ได้เปิดอยู่' } }
  'status' {
    $dir = FindDir; $st = LoadState $dir
    Say ("โฟลเดอร์: {0} · ติดตั้งแล้ว: {1}" -f $dir, [bool]$st)
    if (ApiUp) {
      $tags = (Invoke-RestMethod "$Base/api/tags").models | ForEach-Object { $_.name }
      Say ("ทำงานอยู่ที่ {0} · โมเดล: {1}" -f $Base, ($tags -join ', ')) 'Green'
    } else { Say 'ไม่ได้ทำงาน' 'DarkYellow' }
  }
  'uninstall' { Uninstall }
}
