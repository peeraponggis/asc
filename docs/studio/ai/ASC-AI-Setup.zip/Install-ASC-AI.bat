@echo off
chcp 65001 >nul
title ASC Studio - AI Assistant Setup
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0asc-ai.ps1" install
echo.
pause
